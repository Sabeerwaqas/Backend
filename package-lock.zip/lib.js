// Method to export module using common.js;

const sum = (num1, num2) => {
    const sum = num1 + num2;
    return sum;
};

exports.sum = sum;